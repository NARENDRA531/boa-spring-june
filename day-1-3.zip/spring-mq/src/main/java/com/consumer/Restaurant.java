package com.consumer;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.config.MessageConfig;
import com.dto.OrderStatus;

@Component
public class Restaurant {

	@RabbitListener(queues = MessageConfig.QUEUE)
	public void consumeMessage(OrderStatus orderStatus) {
		System.out.println("Order recieved from Queue  "+ orderStatus);
	}
}
