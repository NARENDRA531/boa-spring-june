package com.example.boaspringservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoaSpringServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
