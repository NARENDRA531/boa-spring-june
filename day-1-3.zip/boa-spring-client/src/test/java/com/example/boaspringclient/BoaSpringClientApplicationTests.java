package com.example.boaspringclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoaSpringClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
