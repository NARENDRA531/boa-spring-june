package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.model.InterestCalculator;
@Service(value = "service")
public class AccountService {
	
	@Autowired
	@Qualifier(value = "sa")
	private InterestCalculator ic;

	public InterestCalculator getIc() {
		return ic;
	}

	public AccountService() {
		System.out.println("inside service");
	}
	public void setIc(InterestCalculator ic) {
		this.ic = ic;
	}

	 public  double service(double amount) {
		 return ic.calculate(amount);
	 }
	 
	 public void init() {
		 System.out.println("service bean initialize");
	 }
	 public void destroy() {
		 System.out.println("service bean destroyed");
	 }
	
	

}
