package com.client;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
// it replaces xml
@Configuration
// scan for annotations
@ComponentScan("com")
public class AppConfig {

}
