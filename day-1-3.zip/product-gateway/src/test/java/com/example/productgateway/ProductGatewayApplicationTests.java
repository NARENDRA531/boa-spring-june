package com.example.productgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
