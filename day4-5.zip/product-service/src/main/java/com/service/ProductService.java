package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ProductDAO;
import com.model.Product;

 

@Service
public class ProductService {
	
	@Autowired
	private ProductDAO dao;
	
	public Product addProduct(Product product) {
		return dao.save(product);
	}
	
	public List<Product> getProducts(){
		return (List<Product>)dao.findAll();
	}

	public List<Product> getProductById(List<Long> plist){
		return (List<Product>)dao.findAllById(plist);
	}
}
