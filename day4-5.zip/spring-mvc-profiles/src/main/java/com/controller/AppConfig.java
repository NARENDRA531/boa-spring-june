package com.controller;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import lombok.Data;

@Configuration
@ConfigurationProperties("spring.datasource")
@Data
public class AppConfig {

	private String driverClassName;
	private String url;
	private String username;
	private String password;

	@Bean
	@Profile("dev")
	public String devDB() {
		System.out.println("Connectd with Dev database");
		System.out.println(driverClassName);
		System.out.println(url);
		return "Dev Connected";
	}

	@Bean
	@Profile("prod")
	public String prodDB() {
		System.out.println("Connectd with prod database");
		System.out.println(driverClassName);
		System.out.println(url);
		return "prod Connected";
	}

	@Bean
	@Profile("test")
	public String testDB() {
		System.out.println("Connectd with test database");
		System.out.println(driverClassName);
		System.out.println(url);
		return "test Connected";
	}
}
