package com.example.boades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoaDiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
